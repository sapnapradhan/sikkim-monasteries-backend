# 🏔️ Sacred Sikkim Monasteries - Backend API

## 📖 Project Description
Backend API for digitizing and showcasing the monasteries of Sikkim. Built for hackathon in 5 days.

## 🚀 Quick Start

### Installation
```bash
git clone https://github.com/YOUR_USERNAME/sikkim-monasteries-backend.git
cd sikkim-monasteries-backend
npm install